# Ishita Gaba — Ready-to-upload GitHub Pages portfolio

Upload ALL files in this folder to the root of:
`ishitagaba-fin/ishitagaba.github.io`

Required files:
- index.html
- mondelez.html
- pepsico.html
- hdfc-mutual-fund.html
- Ishita_Gaba_Resume.pdf
- Mondelez_Equity_Research_Report.pdf
- PepsiCo_WACC_DCF_Valuation.xlsx

The project links are already wired:
- Mondelēz → detailed research page → full PDF
- PepsiCo → valuation page → Excel model
- HDFC Mutual Fund → project overview
- Résumé buttons → Ishita_Gaba_Resume.pdf
- Email → i.iishitagaba@gmail.com
- LinkedIn → linkedin.com/in/ishita-gaba

No README is required for the website to work.
